import requests
from bs4 import BeautifulSoup
from requests.auth import HTTPBasicAuth
import re


def fetch_issues_from_board(base_url, board_id, email, api_token):
    """Scrape the board UI HTML and extract issue keys if possible."""
    url = f"{base_url}/jira/software/projects/KAN/boards/{board_id}"
    headers = {"Accept": "text/html"}  # explicitly accept HTML
    auth = HTTPBasicAuth(email, api_token)

    print(f"\n📡 Requesting board page: {url}")
    response = requests.get(url, headers=headers, auth=auth)

    print("📥 Status Code:", response.status_code)
    content_type = response.headers.get("Content-Type", "")
    print("🔍 Content-Type:", content_type)

    if "text/html" not in content_type:
        print("❌ Not an HTML page. You may need to log in.")
        return []

    soup = BeautifulSoup(response.text, "html.parser")

    # Attempt to extract issue keys like "KAN-123"
    issue_keys = set(re.findall(r'\bKAN-\d+\b', soup.text))
    issue_list = [{"key": key} for key in issue_keys]

    if issue_list:
        print(f"✅ Found {len(issue_list)} issue keys.")
    else:
        print("⚠️ No issue keys found in raw HTML.")

    return issue_list

# ---------------- Test ----------------
if __name__ == "__main__":
    BASE_URL = "https://inaiai4.atlassian.net"
    BOARD_ID = "1"  # ✅ Use the board ID shown in the board URL
    EMAIL = "shreyas0702@gmail.com"
    API_TOKEN = ""  # ⚠️ Replace this with your actual token

    issues = fetch_issues_from_board(BASE_URL, BOARD_ID, EMAIL, API_TOKEN)
    print(f"\n✅ Fetched {len(issues)} issues from board {BOARD_ID}")
    for issue in issues[:5]:
        print(f"{issue['key']} - {issue['fields']['summary']}")
