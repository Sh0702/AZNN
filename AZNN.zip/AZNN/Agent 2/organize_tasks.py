from collections import defaultdict
import json

def organize_tasks_by_employee(issues):
    employee_tasks = defaultdict(list)
    for issue in issues:
        fields = issue["fields"]
        assignee = fields["assignee"]["displayName"] if fields.get("assignee") else "Unassigned"
        task = {
            "summary": fields["summary"],
            "status": fields["status"]["name"],
            "duedate": fields.get("duedate"),
            "completed": fields.get("resolutiondate")
        }
        employee_tasks[assignee].append(task)
    return dict(employee_tasks)

# ---------------- Test ----------------
if __name__ == "__main__":
    mock_issues = [{
        "fields": {
            "summary": "Fix bug #23",
            "status": {"name": "Done"},
            "assignee": {"displayName": "Alice"},
            "duedate": "2025-04-01",
            "resolutiondate": "2025-03-31"
        }
    }]
    grouped = organize_tasks_by_employee(mock_issues)
    print(grouped)
# Save the result to a file
with open("summary_jira.json", "w") as f:
    json.dump(grouped, f, indent=2)

print("✅ Summary saved to summary_jira.json")
